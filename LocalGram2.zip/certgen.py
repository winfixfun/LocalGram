"""Pure-Python self-signed X.509 certificate generator (no external packages)."""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import ipaddress
import math
import os
import secrets
import ssl
from pathlib import Path


def _len(n: int) -> bytes:
    if n < 128:
        return bytes([n])
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(raw)]) + raw


def _tlv(tag: int, data: bytes) -> bytes:
    return bytes([tag]) + _len(len(data)) + data


def _seq(*parts: bytes) -> bytes:
    return _tlv(0x30, b"".join(parts))


def _set(*parts: bytes) -> bytes:
    return _tlv(0x31, b"".join(parts))


def _int(n: int) -> bytes:
    raw = n.to_bytes(max(1, (n.bit_length() + 7) // 8), "big")
    if raw[0] & 0x80:
        raw = b"\0" + raw
    return _tlv(0x02, raw)


def _oid(*nums: int) -> bytes:
    first = bytes([40 * nums[0] + nums[1]])
    out = bytearray(first)
    for n in nums[2:]:
        stack = [n & 0x7F]
        n >>= 7
        while n:
            stack.append(0x80 | (n & 0x7F))
            n >>= 7
        out.extend(reversed(stack))
    return _tlv(0x06, bytes(out))


def _null() -> bytes:
    return b"\x05\x00"


def _utf8(value: str) -> bytes:
    return _tlv(0x0C, value.encode("utf-8"))


def _bit_string(data: bytes) -> bytes:
    return _tlv(0x03, b"\0" + data)


def _octet(data: bytes) -> bytes:
    return _tlv(0x04, data)


def _ctx(number: int, data: bytes, constructed: bool = True) -> bytes:
    return _tlv((0xA0 if constructed else 0x80) + number, data)


def _pem(label: str, data: bytes) -> bytes:
    body = base64.encodebytes(data).replace(b"\n", b"")
    lines = [body[i:i + 64] for i in range(0, len(body), 64)]
    return (f"-----BEGIN {label}-----\n".encode() + b"\n".join(lines) +
            f"\n-----END {label}-----\n".encode())


def _is_probable_prime(n: int, rounds: int = 32) -> bool:
    small = (3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43)
    if n < 2 or n % 2 == 0:
        return n == 2
    if any(n % p == 0 for p in small):
        return n in small
    d, s = n - 1, 0
    while d % 2 == 0:
        s += 1
        d //= 2
    for _ in range(rounds):
        a = secrets.randbelow(n - 3) + 2
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def _prime(bits: int) -> int:
    while True:
        n = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        if _is_probable_prime(n):
            return n


def ensure_certificate(cert_path: Path, key_path: Path) -> None:
    if cert_path.exists() and key_path.exists():
        try:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.load_cert_chain(cert_path, key_path)
            return
        except (ssl.SSLError, OSError):
            cert_path.unlink(missing_ok=True)
            key_path.unlink(missing_ok=True)
    cert_path.parent.mkdir(parents=True, exist_ok=True)
    e = 65537
    while True:
        p, q = _prime(1024), _prime(1024)
        if p != q and math.gcd(e, (p - 1) * (q - 1)) == 1:
            break
    if p < q:
        p, q = q, p
    n = p * q
    phi = (p - 1) * (q - 1)
    d = pow(e, -1, phi)
    key_der = _seq(_int(0), _int(n), _int(e), _int(d), _int(p), _int(q),
                   _int(d % (p - 1)), _int(d % (q - 1)), _int(pow(q, -1, p)))

    sha256_rsa = _seq(_oid(1, 2, 840, 113549, 1, 1, 11), _null())
    rsa_pub = _seq(_int(n), _int(e))
    pub_info = _seq(_seq(_oid(1, 2, 840, 113549, 1, 1, 1), _null()), _bit_string(rsa_pub))
    name = _seq(_set(_seq(_oid(2, 5, 4, 3), _utf8("LocalGram"))))
    now = dt.datetime.now(dt.timezone.utc)
    utc_time = lambda x: _tlv(0x17, x.strftime("%y%m%d%H%M%SZ").encode())
    validity = _seq(utc_time(now - dt.timedelta(days=1)), utc_time(now + dt.timedelta(days=3650)))

    san = _seq(_tlv(0x82, b"localhost"), _tlv(0x87, ipaddress.ip_address("127.0.0.1").packed))
    san_ext = _seq(_oid(2, 5, 29, 17), _octet(san))
    basic_ext = _seq(_oid(2, 5, 29, 19), _tlv(0x01, b"\xff"), _octet(_seq()))
    extensions = _ctx(3, _seq(basic_ext, san_ext))
    tbs = _seq(_ctx(0, _int(2)), _int(secrets.randbits(128)), sha256_rsa,
               name, validity, name, pub_info, extensions)
    digest_info = _seq(_seq(_oid(2, 16, 840, 1, 101, 3, 4, 2, 1), _null()),
                       _octet(hashlib.sha256(tbs).digest()))
    size = (n.bit_length() + 7) // 8
    padding = b"\xff" * (size - len(digest_info) - 3)
    signature = pow(int.from_bytes(b"\x00\x01" + padding + b"\x00" + digest_info, "big"), d, n).to_bytes(size, "big")
    cert_der = _seq(tbs, sha256_rsa, _bit_string(signature))

    key_path.write_bytes(_pem("RSA PRIVATE KEY", key_der))
    cert_path.write_bytes(_pem("CERTIFICATE", cert_der))
    try:
        os.chmod(key_path, 0o600)
    except OSError:
        pass
