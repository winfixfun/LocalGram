from __future__ import annotations

import json
import sqlite3
import ssl
import sys
import urllib.request
from pathlib import Path

BASE = sys.argv[1] if len(sys.argv) > 1 else "https://127.0.0.1:9443"
ROOT = Path(__file__).resolve().parents[1]
DB_PATH = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "instance_test" / "localgram.db"
CTX = ssl._create_unverified_context()


def request(path, method="GET", payload=None, cookie="", csrf=""):
    headers = {}
    if cookie:
        headers["Cookie"] = cookie
    if csrf:
        headers["X-CSRF-Token"] = csrf
    if payload is not None:
        headers["Content-Type"] = "application/json"
        payload = json.dumps(payload).encode()
    req = urllib.request.Request(BASE + path, method=method, data=payload, headers=headers)
    with urllib.request.urlopen(req, context=CTX) as response:
        body = response.read()
        parsed = json.loads(body) if "application/json" in response.headers.get("Content-Type", "") else body
        return parsed, response.headers.get("Set-Cookie", "").split(";", 1)[0]


def main():
    db = sqlite3.connect(DB_PATH)
    username = db.execute("SELECT username FROM users WHERE username LIKE 'Alice_%' ORDER BY id DESC LIMIT 1").fetchone()[0]
    expected = db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    db.close()

    session, cookie = request("/api/session")
    logged, cookie = request("/api/login", "POST", {"username": username, "password": "strong-pass-1"}, cookie, session["csrf_token"])
    chats, _ = request("/api/chats", cookie=cookie)
    assert logged["user"]["username"] == username
    assert chats["chats"], "После перезапуска пропали чаты"
    attachment = None
    found_messages = 0
    for chat in chats["chats"]:
        messages, _ = request(f"/api/chats/{chat['id']}/messages", cookie=cookie)
        found_messages += len(messages["messages"])
        for message in messages["messages"]:
            if message["attachment"] and message["attachment"]["original_name"] == "proof.bin":
                attachment = message["attachment"]
                break
        if attachment:
            break
    assert found_messages and expected > 0, "После перезапуска пропали сообщения"
    assert attachment, "После перезапуска пропало тестовое вложение"
    data, _ = request(attachment["url"], cookie=cookie)
    assert data == b"localgram-smoke-file", "После перезапуска изменился файл"
    print("PERSISTENCE TEST PASSED: user, session, chat, message and file survived restart")


if __name__ == "__main__":
    main()
