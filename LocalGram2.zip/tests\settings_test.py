from __future__ import annotations

import json
import secrets
import sqlite3
import ssl
import sys
import urllib.error
import urllib.request
from pathlib import Path

BASE = sys.argv[1] if len(sys.argv) > 1 else "https://127.0.0.1:9445"
DB_PATH = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).resolve().parents[1] / "instance_test" / "localgram.db"
CTX = ssl._create_unverified_context()


class Client:
    def __init__(self):
        self.cookie = ""
        self.csrf = ""

    def call(self, path, method="GET", data=None, content_type="application/json"):
        headers = {}
        if self.cookie:
            headers["Cookie"] = self.cookie
        if method != "GET":
            headers["X-CSRF-Token"] = self.csrf
        if data is not None:
            headers["Content-Type"] = content_type
        req = urllib.request.Request(BASE + path, method=method, data=data, headers=headers)
        try:
            response = urllib.request.urlopen(req, context=CTX)
        except urllib.error.HTTPError as error:
            return error.code, json.loads(error.read())
        with response:
            cookie = response.headers.get("Set-Cookie")
            if cookie:
                self.cookie = cookie.split(";", 1)[0]
            raw = response.read()
            body = json.loads(raw) if raw else {}
            if body.get("csrf_token"):
                self.csrf = body["csrf_token"]
            return response.status, body

    def register(self, username, password="profile-pass"):
        self.call("/api/session")
        boundary = "----settings" + secrets.token_hex(8)
        fields = {"username": username, "password": password, "first_name": "OldName", "last_name": "OldLast"}
        data = b"".join(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{key}\"\r\n\r\n{value}\r\n".encode() for key, value in fields.items()) + f"--{boundary}--\r\n".encode()
        return self.call("/api/register", "POST", data, f"multipart/form-data; boundary={boundary}")


def multipart(fields, file_field=None):
    boundary = "----profile" + secrets.token_hex(8)
    chunks = [f"--{boundary}\r\nContent-Disposition: form-data; name=\"{key}\"\r\n\r\n{value}\r\n".encode() for key, value in fields.items()]
    if file_field:
        name, filename, mime, payload = file_field
        chunks.extend([f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; filename=\"{filename}\"\r\nContent-Type: {mime}\r\n\r\n".encode(), payload, b"\r\n"])
    chunks.append(f"--{boundary}--\r\n".encode())
    return b"".join(chunks), f"multipart/form-data; boundary={boundary}"


def main():
    suffix = secrets.token_hex(3)
    owner, peer = Client(), Client()
    status, created = owner.register("Profile_" + suffix)
    assert status == 201
    owner_id = created["user"]["id"]
    status, peer_created = peer.register("Peer_" + suffix)
    assert status == 201
    peer_id = peer_created["user"]["id"]

    owner_chats = owner.call("/api/chats")[1]["chats"]
    peer_chats = peer.call("/api/chats")[1]["chats"]
    assert any(chat["other"]["id"] == peer_id for chat in owner_chats)
    assert any(chat["other"]["id"] == owner_id for chat in peer_chats)
    chat_id = next(chat["id"] for chat in owner_chats if chat["other"]["id"] == peer_id)

    png = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489")
    data, mime = multipart({"first_name": "Новое_Имя1", "last_name": "Фамилия_2", "birth_date": "1999-12-31"}, ("avatar", "avatar.png", "image/png", png))
    status, updated = owner.call("/api/profile", "POST", data, mime)
    assert status == 200 and updated["user"]["first_name"] == "Новое_Имя1" and updated["user"]["has_avatar"]

    status, _ = owner.call("/api/profile/password", "POST", json.dumps({"old_password": "wrong", "new_password": "new-secure-pass"}).encode())
    assert status == 403, "Пароль изменился без правильного старого пароля"
    status, _ = owner.call("/api/profile/password", "POST", json.dumps({"old_password": "profile-pass", "new_password": "new-secure-pass"}).encode())
    assert status == 200

    last_username = None
    for index in range(10):
        last_username = f"Ren{index}_{suffix}"
        status, changed = owner.call("/api/profile/username", "POST", json.dumps({"username": last_username}).encode())
        assert status == 200 and changed["username_changes_remaining"] == 9 - index
    status, limited = owner.call("/api/profile/username", "POST", json.dumps({"username": "Blocked_" + suffix}).encode())
    assert status == 429 and limited["username_changes_remaining"] == 0 and limited["username_limit_resets_at"]

    data = b"------x\r\nContent-Disposition: form-data; name=\"text\"\r\n\r\nbefore delete\r\n------x--\r\n"
    status, sent = owner.call(f"/api/chats/{chat_id}/messages", "POST", data, "multipart/form-data; boundary=----x")
    assert status == 201

    status, _ = owner.call("/api/account", "DELETE", json.dumps({"password": "wrong"}).encode())
    assert status == 403
    status, _ = owner.call("/api/account", "DELETE", json.dumps({"password": "new-secure-pass"}).encode())
    assert status == 200
    status, _ = owner.call("/api/profile")
    assert status == 401

    db = sqlite3.connect(DB_PATH)
    assert db.execute("SELECT COUNT(*) FROM users WHERE id=?", (owner_id,)).fetchone()[0] == 0
    assert db.execute("SELECT COUNT(*) FROM chats WHERE id=?", (chat_id,)).fetchone()[0] == 0
    assert db.execute("SELECT COUNT(*) FROM messages WHERE chat_id=?", (chat_id,)).fetchone()[0] == 0
    regenerated = db.execute("SELECT COUNT(*) FROM direct_chats WHERE user_low=? OR user_high=?", (owner_id, owner_id)).fetchone()[0]
    assert regenerated == 0
    db.close()
    print("SETTINGS TEST PASSED: profile, password, username limit, automatic chats, account deletion")


if __name__ == "__main__":
    main()
