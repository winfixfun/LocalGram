from __future__ import annotations

import json
import secrets
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "https://127.0.0.1:9443"
CTX = ssl._create_unverified_context()


class Client:
    def __init__(self):
        self.cookies = ""
        self.csrf = ""

    def call(self, path, method="GET", data=None, content_type=None):
        headers = {}
        if self.cookies:
            headers["Cookie"] = self.cookies
        if method != "GET":
            headers["X-CSRF-Token"] = self.csrf
        if content_type:
            headers["Content-Type"] = content_type
        req = urllib.request.Request(BASE + path, data=data, method=method, headers=headers)
        with urllib.request.urlopen(req, context=CTX) as res:
            cookie = res.headers.get("Set-Cookie")
            if cookie:
                self.cookies = cookie.split(";", 1)[0]
            raw = res.read()
            body = json.loads(raw) if "application/json" in res.headers.get("Content-Type", "") else raw
            if isinstance(body, dict) and body.get("csrf_token"):
                self.csrf = body["csrf_token"]
            return body, res.headers

    def session(self):
        return self.call("/api/session")[0]


def multipart(fields, file_field=None):
    boundary = "----LocalGram" + secrets.token_hex(12)
    chunks = []
    for name, value in fields.items():
        chunks += [f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n".encode()]
    if file_field:
        field, filename, payload = file_field
        chunks += [f"--{boundary}\r\nContent-Disposition: form-data; name=\"{field}\"; filename=\"{filename}\"\r\nContent-Type: application/octet-stream\r\n\r\n".encode(), payload, b"\r\n"]
    chunks += [f"--{boundary}--\r\n".encode()]
    return b"".join(chunks), f"multipart/form-data; boundary={boundary}"


def register(client, username):
    client.session()
    data, mime = multipart({"username": username, "password": "strong-pass-1", "first_name": "Test_1", "last_name": "User_2", "birth_date": "2000-01-01"})
    return client.call("/api/register", "POST", data, mime)[0]


def main():
    suffix = secrets.token_hex(4)
    alice, bob = Client(), Client()
    a = register(alice, "Alice_" + suffix)
    b = register(bob, "Bob_" + suffix)
    assert a["user"]["username"].startswith("Alice_")

    alice.call("/api/logout", "POST", b"")
    alice.session()
    login_data = json.dumps({"username": ("ALICE_" + suffix.upper()), "password": "strong-pass-1"}).encode()
    logged = alice.call("/api/login", "POST", login_data, "application/json")[0]
    assert logged["user"]["id"] == a["user"]["id"], "Регистронезависимый вход не сработал"

    chats = alice.call("/api/chats")[0]["chats"]
    matching = [chat for chat in chats if chat["other"]["id"] == b["user"]["id"]]
    assert len(matching) == 1, "Автоматический личный чат не создан"
    chat_id = matching[0]["id"]
    data, mime = multipart({"text": "Привет <script>alert(1)</script>"}, ("file", "proof.bin", b"localgram-smoke-file"))
    sent = alice.call(f"/api/chats/{chat_id}/messages", "POST", data, mime)[0]["message"]
    assert sent["text"] == "Привет <script>alert(1)</script>"
    messages = bob.call(f"/api/chats/{chat_id}/messages")[0]["messages"]
    assert messages[-1]["attachment"]["original_name"] == "proof.bin"
    downloaded, headers = bob.call(messages[-1]["attachment"]["url"])
    assert downloaded == b"localgram-smoke-file"
    assert "attachment" in headers.get("Content-Disposition", "")
    print("SMOKE TEST PASSED: register, logout/login, automatic chat, text, file upload/download")


if __name__ == "__main__":
    main()
