from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import io
import mimetypes
import os
import re
import secrets
import socket
import sqlite3
import ssl
import struct
import unicodedata
from functools import wraps
from pathlib import Path

from flask import Flask, abort, g, jsonify, render_template, request, send_file, session
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.utils import secure_filename

from certgen import ensure_certificate

BASE_DIR = Path(__file__).resolve().parent
TESTING = os.getenv("LOCALGRAM_TESTING") == "1"
INSTANCE_DIR = Path(os.getenv("LOCALGRAM_INSTANCE_DIR", BASE_DIR / ("instance_test" if TESTING else "instance"))).resolve()
INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = INSTANCE_DIR / "localgram.db"
MAX_FILE_MB = max(1, min(100, int(os.getenv("LOCALGRAM_MAX_FILE_MB", "25"))))
MAX_FILE_BYTES = MAX_FILE_MB * 1024 * 1024
MAX_AVATAR_SOURCE = 5 * 1024 * 1024
MAX_AVATAR_STORED = 1024 * 1024
USERNAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{2,19}$")
NAME_RE = re.compile(r"^[^\W]+$", re.UNICODE)

app = Flask(__name__)
app.config.update(
    SECRET_KEY=(INSTANCE_DIR / "session.key").read_bytes() if (INSTANCE_DIR / "session.key").exists() else secrets.token_bytes(32),
    MAX_CONTENT_LENGTH=MAX_FILE_BYTES + 1024 * 1024,
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=dt.timedelta(days=7),
)
if not (INSTANCE_DIR / "session.key").exists():
    (INSTANCE_DIR / "session.key").write_bytes(app.config["SECRET_KEY"])
    try:
        os.chmod(INSTANCE_DIR / "session.key", 0o600)
    except OSError:
        pass

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 username_norm TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 first_name TEXT NOT NULL,
 last_name TEXT NOT NULL DEFAULT '',
 birth_date TEXT,
 avatar_data BLOB,
 avatar_mime TEXT,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chats (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_members (
 chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 joined_at TEXT NOT NULL,
 PRIMARY KEY(chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
 sender_id INTEGER NOT NULL REFERENCES users(id),
 text TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id, id);
CREATE TABLE IF NOT EXISTS attachments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 message_id INTEGER NOT NULL UNIQUE REFERENCES messages(id) ON DELETE CASCADE,
 original_name TEXT NOT NULL,
 mime_type TEXT NOT NULL,
 size INTEGER NOT NULL,
 sha256 TEXT NOT NULL,
 data BLOB NOT NULL
);
CREATE TABLE IF NOT EXISTS rate_limits (
 bucket TEXT NOT NULL,
 identity TEXT NOT NULL,
 window_start INTEGER NOT NULL,
 hits INTEGER NOT NULL,
 PRIMARY KEY(bucket, identity)
);
CREATE TABLE IF NOT EXISTS direct_chats (
 user_low INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 user_high INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 chat_id INTEGER NOT NULL UNIQUE REFERENCES chats(id) ON DELETE CASCADE,
 PRIMARY KEY(user_low, user_high),
 CHECK(user_low < user_high)
);
CREATE TABLE IF NOT EXISTS username_changes (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 old_username TEXT NOT NULL,
 new_username TEXT NOT NULL,
 change_date TEXT NOT NULL,
 changed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_username_changes_user_date ON username_changes(user_id, change_date);
"""


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=10)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
        g.db.execute("PRAGMA busy_timeout=10000")
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db:
        db.close()


def ensure_direct_chat(db: sqlite3.Connection, first_id: int, second_id: int) -> int:
    low, high = sorted((first_id, second_id))
    row = db.execute("SELECT chat_id FROM direct_chats WHERE user_low=? AND user_high=?", (low, high)).fetchone()
    if row:
        return row[0]
    legacy = db.execute("SELECT c.id FROM chats c WHERE (SELECT COUNT(*) FROM chat_members WHERE chat_id=c.id)=2 AND EXISTS(SELECT 1 FROM chat_members WHERE chat_id=c.id AND user_id=?) AND EXISTS(SELECT 1 FROM chat_members WHERE chat_id=c.id AND user_id=?) LIMIT 1", (low, high)).fetchone()
    if legacy:
        chat_id = legacy[0]
    else:
        cursor = db.execute("INSERT INTO chats(created_at) VALUES(?)", (now_iso(),))
        chat_id = cursor.lastrowid
        db.executemany("INSERT INTO chat_members(chat_id,user_id,joined_at) VALUES(?,?,?)", [(chat_id, low, now_iso()), (chat_id, high, now_iso())])
    db.execute("INSERT OR IGNORE INTO direct_chats(user_low,user_high,chat_id) VALUES(?,?,?)", (low, high, chat_id))
    return chat_id


def sync_direct_chats(db: sqlite3.Connection) -> None:
    user_ids = [row[0] for row in db.execute("SELECT id FROM users ORDER BY id")]
    for index, first_id in enumerate(user_ids):
        for second_id in user_ids[index + 1:]:
            ensure_direct_chat(db, first_id, second_id)


def init_db() -> None:
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("PRAGMA journal_mode=WAL;" + SCHEMA)
    sync_direct_chats(db)
    db.commit()
    db.close()


def api_error(message: str, status: int = 400):
    return jsonify(error=message), status


def client_ip() -> str:
    return request.remote_addr or "unknown"


def rate_limit(bucket: str, limit: int, window_seconds: int, identity: str | None = None) -> bool:
    identity = identity or client_ip()
    now = int(dt.datetime.now().timestamp())
    db = get_db()
    row = db.execute("SELECT window_start,hits FROM rate_limits WHERE bucket=? AND identity=?", (bucket, identity)).fetchone()
    if not row or now - row["window_start"] >= window_seconds:
        db.execute("INSERT INTO rate_limits(bucket,identity,window_start,hits) VALUES(?,?,?,1) ON CONFLICT(bucket,identity) DO UPDATE SET window_start=excluded.window_start,hits=1", (bucket, identity, now))
        db.commit()
        return True
    if row["hits"] >= limit:
        return False
    db.execute("UPDATE rate_limits SET hits=hits+1 WHERE bucket=? AND identity=?", (bucket, identity))
    db.commit()
    return True


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    iterations = 310_000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    return f"pbkdf2_sha256${iterations}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algorithm, iterations, salt_hex, digest_hex = stored.split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), int(iterations))
        return hmac.compare_digest(actual, bytes.fromhex(digest_hex))
    except (ValueError, TypeError):
        return False


def validate_name(value: object, label: str, required: bool) -> tuple[str | None, str | None]:
    text = str(value or "").strip()
    if not text and not required:
        return "", None
    if not 1 <= len(text) <= 40 or not NAME_RE.fullmatch(text):
        return None, f"{label}: 1–40 букв, цифр или символов подчёркивания"
    return text, None


def parse_birth_date(value: object) -> tuple[str | None, str | None]:
    text = str(value or "").strip()
    if not text:
        return None, None
    try:
        date = dt.date.fromisoformat(text)
    except ValueError:
        return None, "Некорректная дата рождения"
    if not dt.date(1900, 1, 1) <= date <= dt.date.today():
        return None, "Дата рождения должна быть между 01.01.1900 и сегодняшним днём"
    return date.isoformat(), None


def parse_avatar(upload):
    if not upload or not upload.filename:
        return None, None, None
    raw = upload.read(MAX_AVATAR_SOURCE + 1)
    if len(raw) > MAX_AVATAR_SOURCE:
        return None, None, "Исходная аватарка больше 5 МБ"
    mime = detect_mime(raw, upload.filename)
    if mime not in {"image/jpeg", "image/png", "image/webp"}:
        return None, None, "Аватарка должна быть JPG, PNG или WebP"
    dimensions = image_dimensions(raw, mime)
    if not dimensions or dimensions[0] > 512 or dimensions[1] > 512 or len(raw) > MAX_AVATAR_STORED:
        return None, None, "Аватарка не обработана: выберите изображение, которое браузер может уменьшить до 512×512"
    return raw, mime, None


def username_limit_status(db: sqlite3.Connection, user_id: int) -> tuple[int, str]:
    today = dt.datetime.now().astimezone().date()
    used = db.execute("SELECT COUNT(*) FROM username_changes WHERE user_id=? AND change_date=?", (user_id, today.isoformat())).fetchone()[0]
    reset_at = dt.datetime.combine(today + dt.timedelta(days=1), dt.time.min).astimezone()
    return max(0, 10 - used), reset_at.isoformat(timespec="seconds")


def image_dimensions(data: bytes, mime: str) -> tuple[int, int] | None:
    try:
        if mime == "image/png" and data.startswith(b"\x89PNG\r\n\x1a\n"):
            return struct.unpack(">II", data[16:24])
        if mime == "image/webp" and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            kind = data[12:16]
            if kind == b"VP8X":
                return (1 + int.from_bytes(data[24:27], "little"), 1 + int.from_bytes(data[27:30], "little"))
            if kind == b"VP8L" and data[20] == 0x2F:
                bits = int.from_bytes(data[21:25], "little")
                return ((bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1)
            if kind == b"VP8 " and data[23:26] == b"\x9d\x01\x2a":
                return (int.from_bytes(data[26:28], "little") & 0x3FFF, int.from_bytes(data[28:30], "little") & 0x3FFF)
        if mime == "image/jpeg" and data.startswith(b"\xff\xd8"):
            pos = 2
            while pos + 9 < len(data):
                if data[pos] != 0xFF:
                    pos += 1
                    continue
                marker = data[pos + 1]
                pos += 2
                if marker in (0xD8, 0xD9):
                    continue
                size = int.from_bytes(data[pos:pos + 2], "big")
                if marker in range(0xC0, 0xC4):
                    return (int.from_bytes(data[pos + 5:pos + 7], "big"), int.from_bytes(data[pos + 3:pos + 5], "big"))
                pos += size
    except (IndexError, struct.error):
        return None
    return None


def detect_mime(data: bytes, filename: str) -> str:
    signatures = [
        (b"\x89PNG\r\n\x1a\n", "image/png"), (b"\xff\xd8\xff", "image/jpeg"),
        (b"GIF87a", "image/gif"), (b"GIF89a", "image/gif"), (b"%PDF-", "application/pdf"),
        (b"PK\x03\x04", "application/zip"), (b"\x7fELF", "application/x-elf"), (b"MZ", "application/vnd.microsoft.portable-executable"),
        (b"OggS", "application/ogg"), (b"ID3", "audio/mpeg"),
    ]
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if len(data) >= 12 and data[4:8] == b"ftyp":
        return "video/mp4"
    for signature, mime in signatures:
        if data.startswith(signature):
            return mime
    guessed = mimetypes.guess_type(filename)[0]
    return guessed or "application/octet-stream"


def current_user():
    uid = session.get("user_id")
    return get_db().execute("SELECT id,username,first_name,last_name,birth_date,avatar_mime,created_at FROM users WHERE id=?", (uid,)).fetchone() if uid else None


def user_json(row):
    return {"id": row["id"], "username": row["username"], "first_name": row["first_name"], "last_name": row["last_name"], "birth_date": row["birth_date"], "has_avatar": bool(row["avatar_mime"]), "avatar_url": f"/api/users/{row['id']}/avatar" if row["avatar_mime"] else None}


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user():
            return api_error("Требуется вход", 401)
        return fn(*args, **kwargs)
    return wrapped


def require_csrf():
    supplied = request.headers.get("X-CSRF-Token", "")
    expected = session.get("csrf_token", "")
    if not expected or not hmac.compare_digest(supplied, expected):
        abort(403, description="Некорректный CSRF-токен")


def is_member(chat_id: int, user_id: int) -> bool:
    return get_db().execute("SELECT 1 FROM chat_members WHERE chat_id=? AND user_id=?", (chat_id, user_id)).fetchone() is not None


def chat_json(chat, user_id: int):
    other = get_db().execute("SELECT u.* FROM users u JOIN chat_members cm ON cm.user_id=u.id WHERE cm.chat_id=? AND u.id<>? LIMIT 1", (chat["id"], user_id)).fetchone()
    last = get_db().execute("SELECT text,created_at FROM messages WHERE chat_id=? ORDER BY id DESC LIMIT 1", (chat["id"],)).fetchone()
    return {"id": chat["id"], "other": user_json(other) if other else None, "last_message": dict(last) if last else None}


def message_json(row):
    attachment = get_db().execute("SELECT id,original_name,mime_type,size FROM attachments WHERE message_id=?", (row["id"],)).fetchone()
    return {"id": row["id"], "chat_id": row["chat_id"], "sender_id": row["sender_id"], "sender_username": row["sender_username"], "text": row["text"], "created_at": row["created_at"], "attachment": ({**dict(attachment), "url": f"/api/attachments/{attachment['id']}"} if attachment else None)}


@app.after_request
def security_headers(response):
    response.headers["Content-Security-Policy"] = "default-src 'self'; img-src 'self' blob: data:; media-src 'self' blob:; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response


@app.errorhandler(RequestEntityTooLarge)
def too_large(_error):
    return api_error(f"Запрос слишком большой. Лимит файла — {MAX_FILE_MB} МБ", 413)


@app.errorhandler(403)
def forbidden(error):
    return api_error(getattr(error, "description", "Доступ запрещён"), 403)


@app.get("/")
def index():
    return render_template("index.html", max_file_mb=MAX_FILE_MB)


@app.get("/api/session")
def get_session():
    user = current_user()
    token = session.get("csrf_token") or secrets.token_urlsafe(32)
    session["csrf_token"] = token
    return jsonify(authenticated=bool(user), user=user_json(user) if user else None, csrf_token=token, max_file_mb=MAX_FILE_MB)


@app.post("/api/register")
def register():
    require_csrf()
    if not rate_limit("register", 30, 3600):
        return api_error("Слишком много регистраций. Повторите позже", 429)
    data = request.form
    username = data.get("username", "").strip()
    password = data.get("password", "")
    if not USERNAME_RE.fullmatch(username):
        return api_error("Username: 3–20 латинских букв, цифр или _, не может начинаться с цифры")
    if not 6 <= len(password) <= 30:
        return api_error("Пароль должен содержать от 6 до 30 символов")
    first_name, error = validate_name(data.get("first_name"), "Имя", True)
    if error:
        return api_error(error)
    last_name, error = validate_name(data.get("last_name"), "Фамилия", False)
    if error:
        return api_error(error)
    birth_date, error = parse_birth_date(data.get("birth_date"))
    if error:
        return api_error(error)
    avatar_data, avatar_mime, error = parse_avatar(request.files.get("avatar"))
    if error:
        return api_error(error)
    db = get_db()
    try:
        cursor = db.execute("INSERT INTO users(username,username_norm,password_hash,first_name,last_name,birth_date,avatar_data,avatar_mime,created_at) VALUES(?,?,?,?,?,?,?,?,?)", (username, username.casefold(), hash_password(password), first_name, last_name, birth_date, avatar_data, avatar_mime, now_iso()))
        new_user_id = cursor.lastrowid
        for row in db.execute("SELECT id FROM users WHERE id<>?", (new_user_id,)).fetchall():
            ensure_direct_chat(db, new_user_id, row["id"])
        db.commit()
    except sqlite3.IntegrityError:
        db.rollback()
        return api_error("Этот username уже занят", 409)
    session.clear()
    session["user_id"] = new_user_id
    session["csrf_token"] = secrets.token_urlsafe(32)
    session.permanent = True
    return jsonify(user=user_json(current_user()), csrf_token=session["csrf_token"]), 201


@app.post("/api/login")
def login():
    require_csrf()
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    identity = f"{client_ip()}:{username.casefold()[:64]}"
    if not rate_limit("login", 8, 300, identity):
        return api_error("Слишком много попыток входа. Подождите 5 минут", 429)
    row = get_db().execute("SELECT * FROM users WHERE username_norm=?", (username.casefold(),)).fetchone()
    if not row or not verify_password(str(data.get("password", "")), row["password_hash"]):
        return api_error("Неверный username или пароль", 401)
    session.clear()
    session["user_id"] = row["id"]
    session["csrf_token"] = secrets.token_urlsafe(32)
    session.permanent = True
    return jsonify(user=user_json(row), csrf_token=session["csrf_token"])


@app.post("/api/logout")
@login_required
def logout():
    require_csrf()
    session.clear()
    return jsonify(ok=True)


@app.get("/api/profile")
@login_required
def get_profile():
    me = current_user()
    remaining, reset_at = username_limit_status(get_db(), me["id"])
    return jsonify(user=user_json(me), username_changes_remaining=remaining, username_limit_resets_at=reset_at)


@app.post("/api/profile")
@login_required
def update_profile():
    require_csrf()
    me = current_user()
    if not rate_limit("profile_update", 30, 3600, str(me["id"])):
        return api_error("Слишком много изменений профиля. Повторите позже", 429)
    first_name, error = validate_name(request.form.get("first_name"), "Имя", True)
    if error:
        return api_error(error)
    last_name, error = validate_name(request.form.get("last_name"), "Фамилия", False)
    if error:
        return api_error(error)
    birth_date, error = parse_birth_date(request.form.get("birth_date"))
    if error:
        return api_error(error)
    avatar_data, avatar_mime, error = parse_avatar(request.files.get("avatar"))
    if error:
        return api_error(error)
    db = get_db()
    if avatar_data is None:
        db.execute("UPDATE users SET first_name=?,last_name=?,birth_date=? WHERE id=?", (first_name, last_name, birth_date, me["id"]))
    else:
        db.execute("UPDATE users SET first_name=?,last_name=?,birth_date=?,avatar_data=?,avatar_mime=? WHERE id=?", (first_name, last_name, birth_date, avatar_data, avatar_mime, me["id"]))
    db.commit()
    return jsonify(user=user_json(current_user()))


@app.post("/api/profile/username")
@login_required
def update_username():
    require_csrf()
    me = current_user()
    if not rate_limit("username_update", 30, 3600, str(me["id"])):
        return api_error("Слишком много запросов на смену username. Повторите позже", 429)
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    if not USERNAME_RE.fullmatch(username):
        return api_error("Username: 3–20 латинских букв, цифр или _, не может начинаться с цифры")
    db = get_db()
    remaining, reset_at = username_limit_status(db, me["id"])
    if username == me["username"]:
        return jsonify(user=user_json(me), username_changes_remaining=remaining, username_limit_resets_at=reset_at)
    if remaining <= 0:
        return jsonify(error=f"Лимит смен username исчерпан. Он сбросится в полночь: {reset_at}", username_changes_remaining=0, username_limit_resets_at=reset_at), 429
    occupied = db.execute("SELECT 1 FROM users WHERE username_norm=? AND id<>?", (username.casefold(), me["id"])).fetchone()
    if occupied:
        return api_error("Этот username уже занят", 409)
    today = dt.datetime.now().astimezone().date().isoformat()
    try:
        db.execute("UPDATE users SET username=?,username_norm=? WHERE id=?", (username, username.casefold(), me["id"]))
        db.execute("INSERT INTO username_changes(user_id,old_username,new_username,change_date,changed_at) VALUES(?,?,?,?,?)", (me["id"], me["username"], username, today, now_iso()))
        db.commit()
    except sqlite3.IntegrityError:
        db.rollback()
        return api_error("Этот username уже занят", 409)
    remaining, reset_at = username_limit_status(db, me["id"])
    return jsonify(user=user_json(current_user()), username_changes_remaining=remaining, username_limit_resets_at=reset_at)


@app.post("/api/profile/password")
@login_required
def update_password():
    require_csrf()
    me = current_user()
    if not rate_limit("password_update", 8, 300, str(me["id"])):
        return api_error("Слишком много попыток смены пароля. Подождите 5 минут", 429)
    data = request.get_json(silent=True) or {}
    old_password = str(data.get("old_password", ""))
    new_password = str(data.get("new_password", ""))
    password_row = get_db().execute("SELECT password_hash FROM users WHERE id=?", (me["id"],)).fetchone()
    if not password_row or not verify_password(old_password, password_row["password_hash"]):
        return api_error("Текущий пароль введён неверно", 403)
    if not 6 <= len(new_password) <= 30:
        return api_error("Новый пароль должен содержать от 6 до 30 символов")
    get_db().execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(new_password), me["id"]))
    get_db().commit()
    return jsonify(ok=True)


@app.delete("/api/account")
@login_required
def delete_account():
    require_csrf()
    me = current_user()
    if not rate_limit("delete_account", 5, 300, str(me["id"])):
        return api_error("Слишком много попыток удаления. Подождите 5 минут", 429)
    data = request.get_json(silent=True) or {}
    password_row = get_db().execute("SELECT password_hash FROM users WHERE id=?", (me["id"],)).fetchone()
    if not password_row or not verify_password(str(data.get("password", "")), password_row["password_hash"]):
        return api_error("Текущий пароль введён неверно", 403)
    db = get_db()
    chat_ids = [row[0] for row in db.execute("SELECT chat_id FROM chat_members WHERE user_id=?", (me["id"],)).fetchall()]
    if chat_ids:
        placeholders = ",".join("?" for _ in chat_ids)
        db.execute(f"DELETE FROM chats WHERE id IN ({placeholders})", chat_ids)
    db.execute("DELETE FROM users WHERE id=?", (me["id"],))
    sync_direct_chats(db)
    db.commit()
    session.clear()
    return jsonify(ok=True)


@app.get("/api/users")
@login_required
def list_users():
    me = current_user()
    rows = get_db().execute("SELECT id,username,first_name,last_name,birth_date,avatar_mime,created_at FROM users WHERE id<>? ORDER BY username_norm", (me["id"],)).fetchall()
    return jsonify(users=[user_json(row) for row in rows])


@app.get("/api/users/<int:user_id>/avatar")
@login_required
def avatar(user_id):
    row = get_db().execute("SELECT username,avatar_data,avatar_mime FROM users WHERE id=?", (user_id,)).fetchone()
    if not row or not row["avatar_data"]:
        abort(404)
    return send_file(io.BytesIO(row["avatar_data"]), mimetype=row["avatar_mime"], download_name=f"{row['username']}-avatar", max_age=3600)


@app.get("/api/chats")
@login_required
def list_chats():
    me = current_user()
    rows = get_db().execute("SELECT c.* FROM chats c JOIN chat_members cm ON cm.chat_id=c.id WHERE cm.user_id=? ORDER BY COALESCE((SELECT MAX(id) FROM messages WHERE chat_id=c.id), c.id) DESC", (me["id"],)).fetchall()
    return jsonify(chats=[chat_json(row, me["id"]) for row in rows])


@app.get("/api/chats/<int:chat_id>/messages")
@login_required
def list_messages(chat_id):
    me = current_user()
    if not is_member(chat_id, me["id"]):
        return api_error("Чат не найден", 404)
    try:
        after = max(0, int(request.args.get("after", 0)))
    except ValueError:
        return api_error("Некорректный параметр after")
    rows = get_db().execute("SELECT m.*,u.username sender_username FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.chat_id=? AND m.id>? ORDER BY m.id LIMIT 200", (chat_id, after)).fetchall()
    return jsonify(messages=[message_json(row) for row in rows])


@app.post("/api/chats/<int:chat_id>/messages")
@login_required
def send_message(chat_id):
    require_csrf()
    me = current_user()
    if not is_member(chat_id, me["id"]):
        return api_error("Чат не найден", 404)
    if not rate_limit("message", 60, 60, str(me["id"])):
        return api_error("Слишком много сообщений. Подождите немного", 429)
    text = request.form.get("text", "")
    if len(text) > 4000:
        return api_error("Сообщение длиннее 4000 символов")
    upload = request.files.get("file")
    raw = None
    if upload and upload.filename:
        if not rate_limit("upload", 20, 3600, str(me["id"])):
            return api_error("Слишком много загруженных файлов", 429)
        raw = upload.read(MAX_FILE_BYTES + 1)
        if len(raw) > MAX_FILE_BYTES:
            return api_error(f"Файл больше {MAX_FILE_MB} МБ", 413)
        if not raw:
            return api_error("Пустой файл не поддерживается")
    if not text.strip() and raw is None:
        return api_error("Введите сообщение или выберите файл")
    db = get_db()
    cursor = db.execute("INSERT INTO messages(chat_id,sender_id,text,created_at) VALUES(?,?,?,?)", (chat_id, me["id"], text, now_iso()))
    if raw is not None:
        display_name = secure_filename(upload.filename) or "file"
        display_name = display_name[:180]
        mime = detect_mime(raw, display_name)
        db.execute("INSERT INTO attachments(message_id,original_name,mime_type,size,sha256,data) VALUES(?,?,?,?,?,?)", (cursor.lastrowid, display_name, mime, len(raw), hashlib.sha256(raw).hexdigest(), raw))
    db.commit()
    row = db.execute("SELECT m.*,u.username sender_username FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=?", (cursor.lastrowid,)).fetchone()
    return jsonify(message=message_json(row)), 201


@app.get("/api/attachments/<int:attachment_id>")
@login_required
def download_attachment(attachment_id):
    me = current_user()
    row = get_db().execute("SELECT a.*,m.chat_id FROM attachments a JOIN messages m ON m.id=a.message_id WHERE a.id=?", (attachment_id,)).fetchone()
    if not row or not is_member(row["chat_id"], me["id"]):
        return api_error("Файл не найден", 404)
    response = send_file(io.BytesIO(row["data"]), mimetype=row["mime_type"], as_attachment=True, download_name=row["original_name"], max_age=0)
    response.headers["Content-Security-Policy"] = "default-src 'none'; sandbox"
    return response


def lan_ips() -> list[str]:
    ips = {"127.0.0.1"}
    try:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(item[4][0])
    except OSError:
        pass
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("8.8.8.8", 80))
        ips.add(probe.getsockname()[0])
        probe.close()
    except OSError:
        pass
    return sorted(ips)


if __name__ == "__main__":
    init_db()
    cert = INSTANCE_DIR / "localgram.crt"
    key = INSTANCE_DIR / "localgram.key"
    if not cert.exists() or not key.exists():
        print("Первый запуск: создаю самоподписанный сертификат (это может занять несколько секунд)...")
    ensure_certificate(cert, key)
    host = os.getenv("LOCALGRAM_HOST", "0.0.0.0")
    port = int(os.getenv("LOCALGRAM_PORT", "8443"))
    print("\nLocalGram доступен по адресам:")
    for ip in lan_ips():
        print(f"  https://{ip}:{port}")
    print("Предупреждение браузера о сертификате ожидаемо. Для остановки нажмите Ctrl+C.\n")
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(cert, key)
    app.run(host=host, port=port, ssl_context=context, threaded=True, debug=False)
