from __future__ import annotations

import json
import secrets
import ssl
import sys
import urllib.error
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "https://127.0.0.1:9443"
CTX = ssl._create_unverified_context()


class Client:
    def __init__(self):
        self.cookie = ""
        self.csrf = ""

    def call(self, path, method="GET", data=None, content_type="application/json", csrf=True):
        headers = {}
        if self.cookie:
            headers["Cookie"] = self.cookie
        if method != "GET" and csrf:
            headers["X-CSRF-Token"] = self.csrf
        if data is not None:
            headers["Content-Type"] = content_type
        req = urllib.request.Request(BASE + path, method=method, data=data, headers=headers)
        try:
            response = urllib.request.urlopen(req, context=CTX)
        except urllib.error.HTTPError as error:
            return error.code, json.loads(error.read())
        with response:
            cookie = response.headers.get("Set-Cookie")
            if cookie:
                self.cookie = cookie.split(";", 1)[0]
            body = json.loads(response.read())
            if body.get("csrf_token"):
                self.csrf = body["csrf_token"]
            return response.status, body

    def init(self):
        return self.call("/api/session")

    def register(self, username):
        boundary = "----test" + secrets.token_hex(8)
        parts = []
        fields = {"username": username, "password": "security-pass", "first_name": "Security_1"}
        for key, value in fields.items():
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{key}\"\r\n\r\n{value}\r\n".encode())
        parts.append(f"--{boundary}--\r\n".encode())
        return self.call("/api/register", "POST", b"".join(parts), f"multipart/form-data; boundary={boundary}")


def main():
    suffix = secrets.token_hex(4)
    owner, duplicate, partner, outsider = Client(), Client(), Client(), Client()
    owner.init(); duplicate.init(); partner.init(); outsider.init()
    status, first = owner.register("Case_" + suffix)
    assert status == 201
    status, _ = duplicate.register("cASE_" + suffix.upper())
    assert status == 409, "Регистронезависимый дубль username разрешён"
    status, second = partner.register("Partner_" + suffix)
    assert status == 201
    status, third = outsider.register("Outside_" + suffix)
    assert status == 201

    status, chats = owner.call("/api/chats")
    matching = [chat for chat in chats["chats"] if chat["other"]["id"] == second["user"]["id"]]
    assert len(matching) == 1, "Автоматический чат не создан"
    target = matching[0]["id"]
    status, _ = outsider.call(f"/api/chats/{target}/messages")
    assert status == 404, "Посторонний пользователь получил доступ к чату"

    status, _ = owner.call("/api/logout", "POST", b"", csrf=False)
    assert status == 403, "Изменяющий запрос прошёл без CSRF-токена"
    print("SECURITY TEST PASSED: case-insensitive uniqueness, chat authorization, CSRF")


if __name__ == "__main__":
    main()
